package partyPlanner;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("Main Menu:");
            System.out.println("1. Sign In");
            System.out.println("2. Sign Up");
            System.out.println("3. Log Out");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    login(scanner);
                    break;
                case 2:
                    signUp(scanner);
                    break;
                case 3:
                    running = false;
                    System.out.println("Logged out.");
                    break;
                default:
                    System.out.println("Invalid choice. Please choose again.");
            }
        }

        scanner.close();
    }

    private static void login(Scanner scanner) {
        System.out.println("Login Menu:");
        System.out.println("Choose user role:");
        System.out.println("1. Administrator");
        System.out.println("2. Customer");
        System.out.println("3. Provider");
        System.out.print("Enter user role choice: ");

        int roleChoice = scanner.nextInt();
        scanner.nextLine(); 

        System.out.print("Enter ID: ");
        String id = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        
        switch (roleChoice) {
            case 1:
             
                if (authenticate(id, password, "users.txt")) {
                    System.out.println("Logged in as Administrator.");
                    // Implement Administrator functionality
                } else {
                    System.out.println("Login failed. Incorrect ID or password.");
                }
                break;
            case 2:
             
                if (authenticate(id, password, "users.txt")) {
                    System.out.println("Logged in as Customer.");
                    // Implement Customer functionality
                } else {
                    System.out.println("Login failed. Incorrect ID or password.");
                }
                break;
            case 3:
            
                if (authenticate(id, password, "users.txt")) {
                    System.out.println("Logged in as Provider.");
                    // Implement Provider functionality
                } else {
                    System.out.println("Login failed. Incorrect ID or password.");
                }
                break;
            default:
                System.out.println("Invalid user role choice.");
        }
    }

    private static boolean authenticate(String id, String password, String filename) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2) { 
                    String existingId = parts[2].trim(); 
                    String existingPassword = parts[3].trim();
                    if (existingId.equals(id) && existingPassword.equals(password)) {
                        return true; 
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    private static void signUp(Scanner scanner) {
        System.out.println("Sign Up:");
        System.out.print("ID: ");
        String id = scanner.nextLine();

        System.out.print("Password: ");
        String password = scanner.nextLine();

        System.out.print("Name: ");
        String name = scanner.nextLine();

        System.out.print("Email: ");
        String email = scanner.nextLine();

        System.out.print("Address: ");
        String address = scanner.nextLine();

        System.out.print("Phone: ");
        String phone = scanner.nextLine();

        User user = new User(id, password, name, email, address, phone);
        if (writeUserToFile(user)) {
            System.out.println("User signed up successfully.");
        } else {
            System.out.println("Sign up failed. User ID or password already exists.");
        }
    }

    private static boolean writeUserToFile(User user) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("users.txt", true))) {
            writer.write(user.getId() + "," + user.getPassword() + "," + user.getName() + "," + user.getEmail() + "," + user.getAddress() + "," + user.getPhone());
            writer.newLine();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false; 
        }
    }
}
