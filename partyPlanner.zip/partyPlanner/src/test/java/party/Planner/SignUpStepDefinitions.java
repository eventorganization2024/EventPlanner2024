package party.Planner;


import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import partyPlanner.User;
import io.cucumber.java.en.Then;


import java.io.*;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class SignUpStepDefinitions {

    User user = new User(null, null, null, null, null, null);

    @Given("the user is on the main menu")
    public void user_on_main_menu() {
        // Simulate user being on the main menu
    }

    @When("the user chooses to sign up")
    public void user_chooses_sign_up() {
        // Simulate user choosing to sign up
    }

    @When("fills in all the required information: name, email, id, password, address, phone")
    public void user_fills_required_information() {
        // Simulate user filling in required information
        user.setName("John Doe");
        user.setEmail("john@example.com");
        user.setId("johndoe123");
        user.setPassword("password123");
        user.setAddress("123 Main Street");
        user.setPhone("1234567890");
    }

    @Then("the user account should be created successfully")
    public void user_account_created_successfully() {
        // Simulate verifying user account creation
        assertTrue(userSignUp());
    }

    @Given("the user is on the sign-up page")
    public void user_on_sign_up_page() {
        // Simulate user being on the sign-up page
    }

    @When("enters an existing user ID")
    public void user_enters_existing_user_ID() {
        // Simulate user entering an existing user ID
        user.setId("existingUser123");
    }

    @When("the user tries to sign up")
    public void user_tries_sign_up() {
        // Simulate user attempting to sign up
    }

    @Then("the sign-up process should fail")
    public void sign_up_process_fail() {
        // Simulate verifying sign-up process failure
        assertFalse(userSignUp());
    }

    @Then("the user should be returned to the main menu")
    public void user_returned_main_menu() {
        // Simulate returning user to the main menu
    }

    // Method to simulate user sign up process
    private boolean userSignUp() {
        // Write user data to text file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("users.txt", true))) {
            writer.write(user.getName() + "," + user.getEmail() + "," + user.getId() + "," + user.getPassword() + "," + user.getAddress() + "," + user.getPhone());
            writer.newLine();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}
