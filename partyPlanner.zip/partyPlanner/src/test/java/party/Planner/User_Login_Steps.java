package party.Planner;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import static org.junit.Assert.*;

public class User_Login_Steps {
    private String id;
    private String password;
    private String errorMessage;
    private boolean loggedIn;

    @Given("the user is on the login page")
    public void userIsOnLoginPage() {
        // Code to navigate to the login page
        System.out.println("User is on the login page.");
    }

    @When("the user enters their ID {string} and password {string}")
    public void userEntersCredentials(String id, String password) {
        this.id = id;
        this.password = password;
        // Code to enter credentials on the login page
        System.out.println("User enters ID: " + id + " and password: " + password);
    }

    @Then("the user should be logged in successfully")
    public void userShouldBeLoggedInSuccessfully() {
        // Code to verify successful login
        assertTrue(loggedIn);
        System.out.println("User logged in successfully.");
    }

    @Then("the user should see an error message {string}")
    public void userShouldSeeErrorMessage(String errorMessage) {
        // Code to verify error message displayed
        assertEquals(errorMessage, this.errorMessage);
        System.out.println("User sees error message: " + errorMessage);
    }
}
