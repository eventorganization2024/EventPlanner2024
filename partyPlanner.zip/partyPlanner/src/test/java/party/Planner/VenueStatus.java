package party.Planner;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class VenueStatus {
	
	
	@Given("there is a venue available for booking")
	public void thereIsAVenueAvailableForBooking() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@When("a user books the venue")
	public void aUserBooksTheVenue() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@Then("the status of the venue should be updated to reserved")
	public void theStatusOfTheVenueShouldBeUpdatedToReserved() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}




}
