package party.Planner;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class VenueMangSteps {
	
	

	@Given("the admin is logged in")
	public void theAdminIsLoggedIn() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@When("the admin is select add a new venue")
	public void theAdminIsSelectAddANewVenue() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@When("filled in all the details about the venue, such as:capacity, amenities, and pricing")
	public void filledInAllTheDetailsAboutTheVenueSuchAsCapacityAmenitiesAndPricing() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("the admin selects the option update the venue")
	public void theAdminSelectsTheOptionUpdateTheVenue() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@When("make the updates on the venue details")
	public void makeTheUpdatesOnTheEnueDetails() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	
	@When("the admin select the option delete the venue")
	public void theAdminSelectTheOptionDeleteTheVenue() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}













}
