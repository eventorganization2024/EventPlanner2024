package party.Planner;

import io.cucumber.java.en.Given;

public class LoginSteps {
	
	


	@Given("that the user is not logged in")
	public void thatTheUserIsNotLoggedIn() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@Given("The user has entered all the password correctly  {string}")
	public void theUserHasEnteredAllThePasswordCorrectly(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}



}
