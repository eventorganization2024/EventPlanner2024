package org.example;

public class Admin {
	boolean state;
    public String getEmail() {
        return "royasmine05@gmail.com";
    }
    public String getAdminId() {
        return "111";
    }
    public String getAdminPassword() {
        return "1234";
    }

    public String getEmailPassword() {
        return "igun bclo kbti fzno";
    }
    public boolean getstate() 
    {
    	return state;
    }
    public void setState(boolean s) {
		this.state =s;
	}

  
}

